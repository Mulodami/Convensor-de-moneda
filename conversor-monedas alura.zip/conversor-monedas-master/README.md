CHALLENGE CONVERSOR DE MONEDAS ALURA LATAM

programa que cuenta con 3 clases.

desde la clase llamada principal se debe ejecutar el proyecto, el cual desplegará un menu.
